package my.model;

public class Product {
	private int pid;
	private String pname;
	private int price;
	private String author;
	private int amount;
	public Product(int pid, String pname, int price, String author, int amount) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.author = author;
		this.amount = amount;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
}
